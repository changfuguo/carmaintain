'use strict';

module.exports = function (mvc) {
    var main = mvc.dataService.create("cart");
};