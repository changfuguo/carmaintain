'use strict';

var _marked = [requestDs].map(regeneratorRuntime.mark);

var ds = module.exports = {};
function requestDs(ctx, httpOptions) {
    var data;
    return regeneratorRuntime.wrap(function requestDs$(_context) {
        while (1) {
            switch (_context.prev = _context.next) {
                case 0:
                    httpOptions.servername = servername;
                    data = null;
                    _context.prev = 2;
                    _context.next = 5;
                    return request(ctx, servername, httpOptions);

                case 5:
                    data = _context.sent;
                    _context.next = 12;
                    break;

                case 8:
                    _context.prev = 8;
                    _context.t0 = _context['catch'](2);

                    logger.warn({
                        logid: ctx.state.logid,
                        errorMessage: _context.t0.message,
                        stack: _context.t0['statck'],
                        test: 'abcdefg'
                    });
                    ctx.throw(ctx.config['error']['backend_request_error']);

                case 12:
                    try {
                        data = JSON.parse(data);
                    } catch (e) {
                        ctx.throw(ctx.config['error']['backend_parse_error']);
                    }

                    if (!(data['status'] && parseInt(data['status']) === 1)) {
                        _context.next = 17;
                        break;
                    }

                    return _context.abrupt('return', data);

                case 17:
                    if (data['status']) {
                        ctx.throw(mapErrorCode(data['status'], ctx, {
                            req: httpOptions,
                            res: data
                        }, { ext: data.ext }));
                    }

                case 18:
                    ctx.throw(ctx.config['error']['backend_unknown_error']);
                    return _context.abrupt('return', null);

                case 20:
                case 'end':
                    return _context.stop();
            }
        }
    }, _marked[0], this, [[2, 8]]);
}