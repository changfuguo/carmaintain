'use strict';

module.exports = function (mvc) {
	var main = mvc.pageService.create("main");

	main.getRenderData = regeneratorRuntime.mark(function _callee(ctx, params) {
		return regeneratorRuntime.wrap(function _callee$(_context) {
			while (1) {
				switch (_context.prev = _context.next) {
					case 0:
						return _context.abrupt("return", { counter: 1000 });

					case 1:
					case "end":
						return _context.stop();
				}
			}
		}, _callee, this);
	});
};