/**
 * Lark Application - index.js
 * Copyright(c) 2015 lark-team
 * MIT Licensed
 */
'use strict';

require('babel-polyfill');

var _lark = require('lark');

var _lark2 = _interopRequireDefault(_lark);

require('isomorphic-fetch');

require('./lib/BaseController');

var _webpack = require('webpack');

var _webpack2 = _interopRequireDefault(_webpack);

var _koaWebpackDevMiddleware = require('koa-webpack-dev-middleware');

var _koaWebpackDevMiddleware2 = _interopRequireDefault(_koaWebpackDevMiddleware);

var _koaWebpackHotMiddleware = require('koa-webpack-hot-middleware');

var _koaWebpackHotMiddleware2 = _interopRequireDefault(_koaWebpackHotMiddleware);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var config = require('./build/config.build');
/*build client for server render**/

var _config$globals = config.globals;
var __DEV__ = _config$globals.__DEV__;
var __PROD__ = _config$globals.__PROD__;


var app = (0, _lark2.default)();

/**here is a demo bu using fetch and promise**/
/***
var sleep = function (time) {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve();
    }, time);
  })
};
var start = async function () {
  // 在这里使用起来就像同步代码那样直观
  console.log('start');
  await sleep(3000);
  console.log('end');
};
start();
**/
if (__DEV__) {
  (function () {

    var chokidar = require('chokidar');
    var watcher = chokidar.watch(['./lib/server.js']);
    var debugpath = require('path');
    watcher.on('ready', function () {
      watcher.on('all', function (event, path) {
        console.log("Clearing /server/ module cache from server");
        console.log(event + ':' + path);
        var fullPath = debugpath.resolve(__dirname, path);
        if (require.cache[fullPath] && fullPath.endsWith('lib/server.js')) {
          console.log('exist ' + fullPath);
          delete require.cache[fullPath];

          require(fullPath);
        }
      });
    });
    var webpackConfig = null;
    webpackConfig = require('./webpack.config.dev')(config);
    webpackConfig = webpackConfig.client;
    webpackConfig.plugins.push(new _webpack2.default.DllReferencePlugin({
      context: __dirname,
      manifest: require('./dist/vendor-manifest.json')
    }));
    var compiler = (0, _webpack2.default)(webpackConfig);
    app.use((0, _koaWebpackDevMiddleware2.default)(compiler, {
      stats: {
        color: true
      },
      inline: true,
      lazy: false,
      hot: true,
      noInfo: true,
      publicPath: webpackConfig.output.publicPath,
      headers: { 'Access-Control-Allow-Origin': '*' },
      //contentBase: "http://" + config.server_host + ':' + config.server_port,
      quiet: true
    }));
    app.use((0, _koaWebpackHotMiddleware2.default)(compiler), {
      heartbeat: 20 * 1000
    });
  })();
} else if (__PROD__) {

  // we do nothing in prod envrioment
}
console.log('start ' + __DEV__ + '  i am here dd aaa');
app.run(function (port) {
  console.log('running on', port);
});