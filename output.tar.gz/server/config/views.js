"use strict";

module.exports = {
  directory: 'views',
  map: {
    ejs: "ejs"
  }
};