/**
 * lark-seed - production.js
 * Copyright(c) 2014 mdemo(https://github.com/demohi)
 * MIT Licensed
 */

'use strict';

module.exports = {
  port: 8080
};