/**
 * lark-seed - development.js
 * Copyright(c) 2014 mdemo(https://github.com/demohi)
 * MIT Licensed
 */

'use strict';

module.exports = {
  port: 3000,
  logging: {
    level: 1
  }
};