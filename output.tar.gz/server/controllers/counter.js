'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var CounterController = function (_BaseController) {
	_inherits(CounterController, _BaseController);

	function CounterController() {
		_classCallCheck(this, CounterController);

		return _possibleConstructorReturn(this, Object.getPrototypeOf(CounterController).call(this, true));
	}

	_createClass(CounterController, [{
		key: 'ActionIndex',
		value: regeneratorRuntime.mark(function ActionIndex(ctx) {
			return regeneratorRuntime.wrap(function ActionIndex$(_context) {
				while (1) {
					switch (_context.prev = _context.next) {
						case 0:
							return _context.abrupt('return', new Promise(function (resolve, reject) {
								resolve({ counter: 330 });
							}));

						case 1:
						case 'end':
							return _context.stop();
					}
				}
			}, ActionIndex, this);
		})
	}, {
		key: 'Action',
		value: regeneratorRuntime.mark(function Action(ctx) {
			return regeneratorRuntime.wrap(function Action$(_context2) {
				while (1) {
					switch (_context2.prev = _context2.next) {
						case 0:
							return _context2.abrupt('return', new Promise(function (resolve, reject) {
								resolve({ counter: 33000 });
							}));

						case 1:
						case 'end':
							return _context2.stop();
					}
				}
			}, Action, this);
		})
	}]);

	return CounterController;
}(BaseController);

module.exports = function (router) {
	new CounterController().route(router);
};